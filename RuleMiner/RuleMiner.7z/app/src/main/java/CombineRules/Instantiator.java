package CombineRules;

import org.neo4j.configuration.GraphDatabaseSettings;
import org.neo4j.dbms.api.DatabaseManagementService;
import org.neo4j.dbms.api.DatabaseManagementServiceBuilder;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.Transaction;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Instantiator {

    public Instantiator(){

    }

    public void write_instantiations(Rule rule, GraphDatabaseService db, int index, String resultFolder) throws Exception {
        String query = "";
        Transaction tx = db.beginTx();
        String func;
        if (rule.functional_variable.equals("a"))
            func = "b";
        else
            func = "a";

        for(Atom atom: rule.body_atoms) {
            query += " MATCH " + atom.neo4j_print();
        }

        query += " MATCH " + rule.head_atom.neo4j_print().replace(func,
                "ap") + "RETURN id(a) AS a, id(b) AS b, id(ap) AS ap";

        Set<String> support = new HashSet<>();
        Set<String> pca = new HashSet<>();
        try {
            Result res = tx.execute(query);
            while (res.hasNext()) {
                Map<String, Object> row = res.next();
                long a = (long) row.get("a"), ap = (long) row.get("ap"), b = (long) row.get("b");
                pca.add(a + "-" + b);

                if (b == ap && rule.functional_variable.equals("a"))
                    support.add(a + "-" + b);
                else if (a == ap && rule.functional_variable.equals("b"))
                    support.add(a + "-" + b);
            }
            res.close();
            this.write_to_file(resultFolder, support, pca, rule, index);
        }catch(Exception e){
            tx.close();
            throw e;
        }
        tx.close();

    }

    public void write_to_file(String folder, Set<String> support, Set<String> pca, Rule rule, int index) throws IOException {
        File f = new File(folder + "\\r" + index + ".txt");
        PrintWriter writer = new PrintWriter(f);
        writer.println(rule.id_print()+","+rule.head_coverage+","+rule.pca_confidence);
        writer.println(support.size());
        for(String res: support){
            String[] splits = res.strip().split("-");
            writer.println(splits[0]+","+splits[1]);
        }
        writer.println(pca.size());

        for(String res: pca){
            String[] splits = res.strip().split("-");
            writer.println(splits[0]+","+splits[1]);
        }
        writer.close();
    }

    public void run_individual(String dataset_name, String model_name) throws IOException {
        String rule_filename = "D:\\PhD\\Work\\EmbeddingInterpretibility\\Interpretibility\\Results\\MinedRules\\" + dataset_name + "\\" + model_name + "_materialized.tsv";
        RuleParser rp = new RuleParser(rule_filename, model_name, dataset_name, "\t");
        rp.parse_rules_from_file(1.0);

        String neo4jFolder = "D:\\PhD\\Work\\EmbeddingInterpretibility\\RuleMiner\\db\\" + dataset_name + "_" + model_name + "_db\\";
        File folder = new File(neo4jFolder);

        DatabaseManagementService service = new DatabaseManagementServiceBuilder(folder.toPath()).
                setConfig(GraphDatabaseSettings.keep_logical_logs, "false").
                setConfig(GraphDatabaseSettings.preallocate_logical_logs, false).build();

        GraphDatabaseService db = service.database("neo4j");
        System.out.println("Started neo4j");

        String resultFolderString = "D:\\PhD\\Work\\EmbeddingInterpretibility\\Interpretibility\\Results\\Instantiations\\" + dataset_name + "\\" + model_name + "\\";
        try {
            int ctr = 0;
            for (String predicate : rp.rules_by_predicate.keySet()) {
                System.out.println("Predicate: " + predicate + "\tPredicates left: " + (rp.rules_by_predicate.keySet().size()-ctr-1));
                ctr+=1;
                File resultFolder = new File(resultFolderString + predicate + "\\");
                if (!resultFolder.exists()) {
                    resultFolder.mkdir();
                }
                List<Rule> rules = rp.rules_by_predicate.get(predicate);

                for (int i = 0; i < rules.size() && i < 25; ++i) {
                    System.out.println("\tRule:" + i);
                    this.write_instantiations(rules.get(i), db, i, resultFolderString + predicate + "\\");
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            service.shutdown();
        }
        service.shutdown();
    }

    public static void main(String[] args) throws IOException {
//        String[] models = new String[]{"ComplEx", "ConvE", "TransE", "TuckER"};
//        String[] datasets = new String[]{"FB15K-237", "FB15K", "WN18", "WN18RR"};
//
//        for (String dataset_name: datasets){
//            for(String model_name: models){
//                System.out.println("Dataset: " + dataset_name + "\tModel: " + model_name);
//                this.run_individual(dataset_name, model_name);
//            }
//        }

        Instantiator obj = new Instantiator();
        obj.run_individual("FB15K-237", "ComplEx");
    }
}
